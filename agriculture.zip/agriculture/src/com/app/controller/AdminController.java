package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.app.dao.IAdminDao;
import com.app.pojos.Course;
import com.app.pojos.Crop;
import com.app.pojos.User;
import com.app.pojos.WholesellerOrder;

@RestController
@CrossOrigin("*")
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private IAdminDao admindao;
	
	@PostMapping(value= ("/addcrop"))
	public ResponseEntity<?> addCrop(@RequestBody Crop cropName)
	{
		
		System.out.println("ewfrgt"+cropName);
		try {
			Crop c=new Crop();
			c.setCropName(cropName.getCropName());
			return new ResponseEntity<Crop>(admindao.addCrop(c),HttpStatus.OK);
			
		} catch (RuntimeException e) {
			
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/*
	 @PostMapping(consumes = {"multipart/form-data"})
	public ResponseEntity<?> addProduct(@RequestParam String category,@RequestParam String pname,
										@RequestParam Float size,@RequestParam Double pcost,
										@RequestParam String desc,@RequestParam MultipartFile uploadimage) throws IOException
	{
		
		System.out.println("in add product dtls "+pcost);
		Category c=Category.valueOf(category);
		ProductDetailsPojo p = new ProductDetailsPojo(c, pname, size, pcost, desc);
		ImagePojo i = new ImagePojo();
		i.setImage(uploadimage.getBytes());
		try {
			
			if(uploadimage!=null)
			{
				System.out.println(uploadimage.getOriginalFilename());
					p.addImage(i);
				ProductDetailsPojo p1=dao2.addProduct(p);
			return new ResponseEntity<ProductDetailsPojo>(p1, HttpStatus.CREATED);
			}
		}
		catch(RuntimeException e)
		{
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);	
		}
		return null;
	}
	 */
	
	
	@GetMapping("/listcrop")
	public ResponseEntity<?> listCrops()
	{
		List<Crop> allcrops=admindao.listCrops();
		System.out.println("inside admin controller list crops "+allcrops);
		if(allcrops.size()==0)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<Crop>>(allcrops,HttpStatus.OK);
	}
	
	
	@DeleteMapping("/crop/{id}")
	public void deleteCrop(@PathVariable int id)
	{
		System.out.println(" in delete Book "+id);
		admindao.deleteCrop(id);
	}
	
	@PostMapping("/addcomputerprofessional")
	public ResponseEntity<?> addComputerprofessional(@RequestBody User u)
	{
		try {
			
			return new ResponseEntity<User>(admindao.addComputerprofessional(u),HttpStatus.CREATED);
			
		} catch (RuntimeException e) {
			
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/listcomputerprofessional")
	public ResponseEntity<?> listcp()
	{
		List<User> allcp=admindao.listcp();
		if(allcp.size()==0)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<User>>(allcp,HttpStatus.OK);
	}
	
	@DeleteMapping("/computerprofessional/{id}")
	public void deletecp(@PathVariable int id)
	{
		admindao.deletecp(id);
	}
	
	 
	 @PostMapping("/addcourse")
	public ResponseEntity<?> addCourse(@RequestBody Course c)
	{
		try {
			
			return new ResponseEntity<Course>(admindao.addCourse(c),HttpStatus.CREATED);
			
		} catch (RuntimeException e) {
			
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@GetMapping("/listcourse")
	public ResponseEntity<?> listCourses()
	{
		List<Course> allcourses=admindao.listCourses();
		if(allcourses.size()==0)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<Course>>(allcourses,HttpStatus.OK);
	}
	
	
	@DeleteMapping("/course/{id}")
	public void deleteCourse(@PathVariable int id)
	{
		System.out.println(" in delete Book "+id);
		admindao.deleteCourse(id);
	}
	 

	@GetMapping("/farmerrecord")
	public ResponseEntity<?> farmerRecord()
	{
		List<User> farmercroprecord=admindao.listFarmerCropRecord();
		if(farmercroprecord.size()==0)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<User>>(farmercroprecord,HttpStatus.OK);
				
				
	}
	
	

	@GetMapping("/wholesellerrecord")
	public ResponseEntity<?> wholesellerRecord()
	{
		List<WholesellerOrder> wholesellerrecord=admindao.listWholeSellerRecord();
		if(wholesellerrecord.size()==0)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<WholesellerOrder>>(wholesellerrecord,HttpStatus.OK);				
	}
	
	

}
