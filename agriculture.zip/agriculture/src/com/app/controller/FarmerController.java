package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.IFarmerDao;
import com.app.pojos.Course;
import com.app.pojos.CourseEnroll;
import com.app.pojos.Crop_Farmer;
import com.app.pojos.Helper;
import com.app.pojos.WholesellerOrder;

@RestController
@RequestMapping("/farmer")
@CrossOrigin
public class FarmerController {

	@Autowired
	private IFarmerDao farmerdao;
	
	@GetMapping("/orderdetails/{id}")
	public ResponseEntity<?> wsOrder(@PathVariable int id){
		
		List<WholesellerOrder> allorders=farmerdao.allOrder(id);
		System.out.println(allorders);
		if(allorders.size()==0)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<WholesellerOrder>>(allorders,HttpStatus.OK);
	}
	
	 @GetMapping("/listcourse")
		public ResponseEntity<?> listCourse()
		{
			List<Course> allcourse=farmerdao.listCourse();
			if(allcourse.size()==0)
				return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
			return new ResponseEntity<List<Course>>(allcourse,HttpStatus.OK);
		}
		
	 @PostMapping("/addcrop")
		public ResponseEntity<?> addCrops(@RequestBody Helper c)
		{
			try {
				System.out.println("inside farmer add crop"+c);
				
				return new ResponseEntity<Crop_Farmer>(farmerdao.addCrop(c),HttpStatus.CREATED);
				
			} catch (RuntimeException e) {
				
				e.printStackTrace();
				return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
	
	
	 @GetMapping("/listcrop/{userId}")
		public ResponseEntity<?> listCrop(@PathVariable int userId)
		{
			List<Crop_Farmer> allcrop=farmerdao.listCrop(userId);
			System.out.println("inside FC list crop  "+allcrop);
			if(allcrop.size()==0)
				return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
			return new ResponseEntity<List<Crop_Farmer>>(allcrop,HttpStatus.OK);
		}
	

	 @GetMapping("/wslistcrop")
		public ResponseEntity<?> listCrop()
		{
			List<Crop_Farmer> allcrop=farmerdao.listCrop();
			System.out.println("inside FC wsslist crop  "+allcrop);
			if(allcrop.size()==0)
				return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
			return new ResponseEntity<List<Crop_Farmer>>(allcrop,HttpStatus.OK);
		}
	 
	 @PostMapping("/wsdata")
		public void wsData(@RequestBody Helper obj)
		{
		 System.out.println(obj);
		 Helper c = new Helper();
		 c.setUserId(obj.getUserId());
		 c.setCropId(obj.getCropId());
		 c.setTotalPrice(obj.getTotalPrice());
		 c.setOrderQty(obj.getOrderQty());
		 System.out.println(" ws orders fc "+c);
			farmerdao.wsOrder(c);
		}
	
	 @PostMapping("/fcrop")
		public void deleteCrop_Farmer(@RequestBody Helper c)
		{
			System.out.println(" in delete Crop_Farmer zzzzz"+c);
			farmerdao.deleteCrop_Farmer(c);
		}
	
	
	 @PutMapping("/crop_farmer/{id}")
		public ResponseEntity<?> updateCrop(@PathVariable int id,@RequestBody Crop_Farmer crop)
		{
			Crop_Farmer currentcrop=farmerdao.listCropById(id);
			if(currentcrop==null)
			{
				return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
			}
			
			currentcrop.setTotalQty(crop.getTotalQty());
			currentcrop.setAvailableQty(crop.getAvailableQty());
			currentcrop.setPrice(crop.getPrice());
			farmerdao.updateCrop(currentcrop);
			return new ResponseEntity<Crop_Farmer>(currentcrop,HttpStatus.OK);
		}
	 
	 @PostMapping("/enroll")
	 public ResponseEntity<?> enroll(@RequestBody Helper course){
		 try {
			 System.out.println("inside enroll helper");
				
				return new ResponseEntity<CourseEnroll>(farmerdao.enroll(course),HttpStatus.CREATED);
				
			} catch (RuntimeException e) {
				
				e.printStackTrace();
				return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
	 }
	
}
