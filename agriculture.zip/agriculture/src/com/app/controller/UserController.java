package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.IUserDao;
import com.app.pojos.Address;
import com.app.pojos.Crop;
import com.app.pojos.Crop_Farmer;
import com.app.pojos.Helper;
import com.app.pojos.User;

@RestController
@CrossOrigin
@RequestMapping("/user")
public class UserController {

	@Autowired
	private IUserDao userdao;
	
	public UserController() {
		
	}
	
	@PostMapping("/adduser")
	public ResponseEntity<?> addUser(@RequestBody User u)
	{
		try {
			
			return new ResponseEntity<User>(userdao.addUser(u),HttpStatus.CREATED);
			
		} catch (RuntimeException e) {
			
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/login")
	public ResponseEntity<?> validateUser(@RequestBody User u)
	{
		try {
			User u1=userdao.validateUser(u);
			System.out.println("inside controller login" +u1.toString());
			return new ResponseEntity<User>(u1,HttpStatus.OK);
			
		} catch (RuntimeException e) {
			// TODO: handle exception
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/userbyid/{id}")
	public ResponseEntity<?> user(@PathVariable int id)
	{
		User u=userdao.user(id);
		System.out.println("inside user controller user "+u);
		if(u==null)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<User>(u,HttpStatus.OK);
	}
	
	@PutMapping("/edit")
	public ResponseEntity<?> updateCrop(@RequestBody Helper u)
	{
		return new ResponseEntity<Helper>(userdao.updateCrop(u),HttpStatus.OK);
	}
		
	
}
