package com.app.dao;

import java.util.List;

import com.app.pojos.Course;
import com.app.pojos.Crop;
import com.app.pojos.User;
import com.app.pojos.WholesellerOrder;

public interface IAdminDao {

	Crop addCrop(Crop c);

	List<Crop> listCrops();

	Crop byId(int id);
	
	void deleteCrop(int id);

	Course addCourse(Course c);

	List<Course> listCourses();
	
	Course cbyId(int id);

	void deleteCourse(int id);

	List<User> listFarmerCropRecord();

	List<WholesellerOrder> listWholeSellerRecord();

	User addUser(User u);

	User addComputerprofessional(User u);

	List<User> listcp();
	
	void deletecp(int id);
	
	User byId2(int id);
}
