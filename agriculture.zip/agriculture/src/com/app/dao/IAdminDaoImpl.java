package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Course;
import com.app.pojos.Crop;
import com.app.pojos.User;
import com.app.pojos.WholesellerOrder;

@Repository
@Transactional
public class IAdminDaoImpl implements IAdminDao {
	
	@Autowired
	private SessionFactory sf;

	@Override
	public Crop addCrop(Crop c) {
		// TODO Auto-generated method stub
		
		sf.getCurrentSession().persist(c);
		return c;
	}

	@Override
	public List<Crop> listCrops() {
		// TODO Auto-generated method stub
		String jpql="Select c from Crop c";
		List<Crop> c= sf.getCurrentSession().createQuery(jpql, Crop.class).getResultList();
		System.out.println("croppppp"+c);
		return c;
	}
	
	@Override
	public Crop byId(int id) {
		// TODO Auto-generated method stub
		return sf.getCurrentSession().get(Crop.class, id);
	}


	@Override
	public void deleteCrop(int id) {
		// TODO Auto-generated method stub
		System.out.println("in dao of delete crop");
		
		sf.getCurrentSession().delete(byId(id));
		
	}

	@Override
	public Course addCourse(Course c) {
		
		System.out.println("Course"+c);
		sf.getCurrentSession().persist(c);
		return c;
	}

	@Override
	public List<Course> listCourses() {
		// TODO Auto-generated method stub
		String jpql="select c from Course c";
		return sf.getCurrentSession().createQuery(jpql, Course.class).getResultList();
	}

	@Override
	public Course cbyId(int id) {
		// TODO Auto-generated method stub
		return sf.getCurrentSession().get(Course.class, id);
	}
	
	@Override
	public void deleteCourse(int id) {
		// TODO Auto-generated method stub
	 sf.getCurrentSession().delete(cbyId(id));
		
	}

	@Override
	public List<User> listFarmerCropRecord() {
		// TODO Auto-generated method stub
		String jpql="Select u.userId,u.fname from User u Left Outer Join u.cropfarmer on u.userId=u.user_FK";
		return sf.getCurrentSession().createQuery(jpql, User.class).getResultList();
	}

	@Override
	public List<WholesellerOrder> listWholeSellerRecord() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User addUser(User u) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User addComputerprofessional(User u) {
		// TODO Auto-generated method stub
		 sf.getCurrentSession().persist(u);
		 return u;
	}

	@Override
	public List<User> listcp() {
		// TODO Auto-generated method stub
		String jpql="Select u from User u where u.role='Computerprofessional'";
		return sf.getCurrentSession().createQuery(jpql, User.class).getResultList();
	}

	@Override
	public void deletecp(int id) {
		// TODO Auto-generated method stub
		sf.getCurrentSession().delete(byId2(id));
	}

	@Override
	public User byId2(int id) {
		// TODO Auto-generated method stub
		
		return sf.getCurrentSession().get(User.class, id);
	}

	

	
}
