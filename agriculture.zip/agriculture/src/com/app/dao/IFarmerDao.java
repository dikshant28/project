package com.app.dao;

import java.util.List;

import com.app.pojos.Course;
import com.app.pojos.CourseEnroll;
import com.app.pojos.Crop_Farmer;
import com.app.pojos.Helper;
import com.app.pojos.User;
import com.app.pojos.WholesellerOrder;

public interface IFarmerDao {

	Crop_Farmer addCrop(Helper c);

	void deleteCrop_Farmer(Helper c);

	void updateCrop(Crop_Farmer currentcrop);

	Crop_Farmer listCropById(int id);

	List<Course> listCourse();

	List<Crop_Farmer> listCrop(int id);

	CourseEnroll enroll(Helper c);

	List<Crop_Farmer> listCrop();

	void wsOrder(Helper c);

	List<WholesellerOrder> allOrder(int id);
}
