	package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Course;
import com.app.pojos.CourseEnroll;
import com.app.pojos.Crop;
import com.app.pojos.Crop_Farmer;
import com.app.pojos.Helper;
import com.app.pojos.User;
import com.app.pojos.WholesellerOrder;

@Repository
@Transactional
public class IFarmerDaoImpl implements IFarmerDao {

	@Autowired
	private SessionFactory sf;
	
	@Override
	public Crop_Farmer addCrop(Helper c) {
		
		System.out.println("inside farmer addCrop Dao IFarmerDao"+c);
		Crop c1= sf.getCurrentSession().get(Crop.class,c.getCropId());
		System.out.println("ccccccccccccc111111  "+c1);
		Crop_Farmer cf=new Crop_Farmer(c.getTotalQty(), c.getAvailableQty(),c.getPrice());
		User u=sf.getCurrentSession().get(User.class, c.getUserId());
		u.addCropfarmer(cf);
		c1.addCropFarmer(cf);
		sf.getCurrentSession().saveOrUpdate(u);
		 System.out.println("inside farmer addCrop Dao IFarmerDao222"+c);
		//sf.getCurrentSession().persist(c);
		 return cf;
	}

	@Override
	public void wsOrder(Helper c) {

		System.out.println("wholeseller orders "+c);
		User u=sf.getCurrentSession().get(User.class, c.getUserId());
		WholesellerOrder o=new WholesellerOrder();
		 o.setTotalPrice(c.getPrice());
		 o.setOrderQty(c.getOrderQty());
		 o.setTotalPrice(c.getTotalPrice());
		 u.addWholesellerOrder(o);
		
	}	
	
	@Override
	public void deleteCrop_Farmer(Helper c) {
		// TODO Auto-generated method stub
		User user=sf.getCurrentSession().get(User.class, c.getUserId());
		Crop_Farmer cf=sf.getCurrentSession().get(Crop_Farmer.class,c.getFarmerId());
		user.removeCropfarmer(cf);
		
	}
	
	public Crop_Farmer byId(int id) {
		// TODO Auto-generated method stub
		return sf.getCurrentSession().get(Crop_Farmer.class, id);
	}

	@Override
	public void updateCrop(Crop_Farmer currentcrop) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Course> listCourse() {
		System.out.println("xyz");
	String jpql="Select c from Course c";
		return sf.getCurrentSession().createQuery(jpql, Course.class).getResultList();
	}

	@Override
	public List<Crop_Farmer> listCrop(int id) {
		// TODO Auto-generated method stub
		String jpql1="select u from User u where userId=:id";
		User u=new User();
		u= sf.getCurrentSession().createQuery(jpql1, User.class).setParameter("id", id).getSingleResult();
		System.out.println("user details  "+u);
		
		return u.getCropfarmer();
	}

	
	@Override
	public List<Crop_Farmer> listCrop() {
		String jpql="select cf from Crop_Farmer cf";
		//Crop_Farmer cf= new Crop_Farmer();
		return sf.getCurrentSession().createQuery(jpql, Crop_Farmer.class).getResultList();
	}
	
	
	@Override
	public CourseEnroll enroll(Helper c) {

		System.out.println(c);
		Course cc=sf.getCurrentSession().get(Course.class, c.getCourseId());
		User u=sf.getCurrentSession().get(User.class, c.getUserId());
		System.out.println(u);
		sf.getCurrentSession().saveOrUpdate(u);
		CourseEnroll ce=new CourseEnroll(c.getCourseId(),c.getUserId());
		u.addCourseEnroll(ce);
		cc.addCourseEnroll(ce);
		System.out.println("ce  "+ce);
		return ce;
	}

	@Override
	public Crop_Farmer listCropById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<WholesellerOrder> allOrder(int id) {
		String jpql1="select u from User u where userId=:id";
		User u=new User();
		u= sf.getCurrentSession().createQuery(jpql1, User.class).setParameter("id", id).getSingleResult();
		System.out.println("user details  "+u);
		
		return u.getWholesellerOrder();
	}

}










