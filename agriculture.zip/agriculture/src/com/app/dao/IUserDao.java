package com.app.dao;

import com.app.pojos.Helper;
import com.app.pojos.User;

public interface IUserDao {

	User addUser(User u);

	User validateUser(User u);

	User user(int id);
	
	Helper updateCrop(Helper u);
}
