package com.app.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Helper;
import com.app.pojos.User;

@Repository
@Transactional
public class IUserDaoImpl implements IUserDao {

	@Autowired
	private SessionFactory sf;
	
	@Override
	public User addUser(User u) {
		// TODO Auto-generated method stub
		System.out.println(u);
		sf.getCurrentSession().persist(u);
		return u;
	}

	@Override
	public User validateUser(User u) {
		// TODO Auto-generated method stub
		String jpql="select u from User u where u.email=:em and u.password=:pass";
		u= sf.getCurrentSession().createQuery(jpql, User.class).setParameter("em", u.getEmail()).setParameter("pass", u.getPassword()).getSingleResult();
		System.out.println("inside dao"+u.toString());
		return u;
	}

	@Override
	public User user(int id) {
		// TODO Auto-generated method stub
		String jpql1="select u from User u where userId=:id";
		User u=new User();
		u= sf.getCurrentSession().createQuery(jpql1, User.class).setParameter("id", id).getSingleResult();
		System.out.println("user details  "+u);
		
		return u;
	}

	@Override
	public Helper updateCrop(Helper u) {
		// TODO Auto-generated method stub
		Helper h=new Helper();
		h.setFname(u.getFname());
		h.setLname(u.getLname());
		h.setPhoneNo(u.getPhoneNo());
		h.setPassword(u.getPassword());
		h.setHouseNo(u.getHouseNo());
		h.setArea(u.getArea());
		h.setCity(u.getCity());
		h.setDistrict(u.getDistrict());
		h.setCountry(u.getCountry());
		h.setPincode(u.getPincode());
		 sf.getCurrentSession().persist(h);
		 return h;
	}

}
