package com.app.dao;

import java.util.List;

import com.app.pojos.Crop;
import com.app.pojos.WholesellerOrder;

public interface IWholesaler {

	List<Crop> listCrops();

	List<WholesellerOrder> listAllOrders(int id);
}
