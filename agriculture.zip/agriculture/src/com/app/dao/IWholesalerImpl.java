package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Crop;
import com.app.pojos.WholesellerOrder;

@Repository
@Transactional
public class IWholesalerImpl implements IWholesaler {

	@Autowired
	private SessionFactory sf;
	
	@Override
	public List<Crop> listCrops() {
		// TODO Auto-generated method stub
		String jpql="Select c From Crop c join fetch c.cropId";
		return sf.getCurrentSession().createQuery(jpql, Crop.class).getResultList();
	}

	@Override
	public List<WholesellerOrder> listAllOrders(int id1) {
		// TODO Auto-generated method stub
		String jpql="Select w From WholesellerOrder Where w.user_FK=:id";
		
		return sf.getCurrentSession().createQuery(jpql, WholesellerOrder.class).setParameter("id", id1).getResultList();
	}

}
