package com.app.pojos;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Address {
	
	private int addressId;
	private int houseNo;
	private String area;
	private String city;
	private String district;
	private String state;
	private String country;
	private int pincode;
	private int phoneNo;
	
	

	public Address() {
		super();
	}

	public Address(int addressId, int houseNo, String area, String city, String district, String state,
			String country, int pincode, int phoneNo, User user) {
		super();
		
		this.addressId = addressId;
		this.houseNo = houseNo;
		this.area = area;
		this.city = city;
		this.district = district;
		this.state = state;
		this.country = country;
		this.pincode = pincode;
		this.phoneNo = phoneNo;
		
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public int getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(int houseNo) {
		this.houseNo = houseNo;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public int getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", houseNo=" + houseNo + ", area=" + area
				+ ", city=" + city + ", district=" + district + ", state=" + state + ", country=" + country
				+ ", pincode=" + pincode + ", phoneNo=" + phoneNo + "]";
	}
}
