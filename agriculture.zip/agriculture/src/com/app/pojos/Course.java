package com.app.pojos;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Course {
	
	private int courseId;
	private String courseName;
	
	private List<CourseEnroll> courseenroll;
	public Course() {
		super();
	}
	public Course(int courseId, String courseName) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	
	@JsonIgnore
	@OneToMany(targetEntity = CourseEnroll.class,mappedBy = "course",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	public List<CourseEnroll> getCourseenroll() {
		return courseenroll;
	}

	public void setCourseenroll(List<CourseEnroll> courseenroll) {
		this.courseenroll = courseenroll;
	}
	
	public void addCourseEnroll(CourseEnroll c)
	{
		courseenroll.add(c);
		c.setCourse(this);
	}
	public void removeCourseEnroll(CourseEnroll c)
	{
		System.out.println("inside user pojo delete fcrop");
		courseenroll.remove(c);
		c.setCourse(null);
	}
	
	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", courseName=" + courseName + "]";
	}
}
