package com.app.pojos;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class CourseEnroll {

	private int enrollId;
	private Date enrollDate;
	
	private User user;
	
	private Course course;

	public CourseEnroll() {
		super();
	}

	public CourseEnroll(int enrollId, Date enrollDate, User user, Course course) {
		super();
		this.enrollId = enrollId;
		this.enrollDate = enrollDate;
		this.user = user;
		this.course = course;
	}

	public CourseEnroll(int courseId, Integer integer) {
		// TODO Auto-generated constructor stub
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getEnrollId() {
		return enrollId;
	}

	public void setEnrollId(int enrollId) {
		this.enrollId = enrollId;
	}

	public Date getEnrollDate() {
		return enrollDate;
	}

	public void setEnrollDate(Date enrollDate) {
		this.enrollDate = enrollDate;
	}

	@OneToOne
	@JoinColumn(name = "user_FK")
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@OneToOne
	@JoinColumn(name = "course_FK")
	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

	@Override
	public String toString() {
		return "CourseEnroll [enrollId=" + enrollId + ", enrollDate=" + enrollDate + ", user=" + user + ", course="
				+ course + "]";
	}
}
