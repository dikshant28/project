package com.app.pojos;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;

import org.springframework.lang.Nullable;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Crop {

	private int cropId;
	private String cropName;
	private MultipartFile photo;
	
	private Set<Crop_Farmer> farmer=new HashSet<>();

	public Crop() {
		super();
	}

	public Crop( String cropName) {
		super();
		//this.cropId = cropId;
		this.cropName = cropName;
		
	}

	public Crop(int cropId2, String cropName2) {
		// TODO Auto-generated constructor stub
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getCropId() {
		return cropId;
	}

	public void setCropId(int cropId) {
		this.cropId = cropId;
	}

	public String getCropName() {
		return cropName;
	}

	public void setCropName(String cropName) {
		this.cropName = cropName;
	}
	
	@Lob
	public MultipartFile getPhoto() {
		return photo;
	}

	public void setPhoto(MultipartFile photo) {
		this.photo = photo;
	}

	@JsonIgnore
	@ManyToMany(mappedBy = "crop",fetch = FetchType.EAGER)
	public Set<Crop_Farmer> getFarmer() {
		return farmer;
	}

	public void setFarmer(Set<Crop_Farmer> farmer) {
		this.farmer = farmer;
	}

	public void addCropFarmer(Crop_Farmer c)
	{
		farmer.add(c);
		c.getCrop().add(this);
	}
	public void removeCropFarmer(Crop_Farmer c)
	{
		System.out.println("inside user pojo delete fcrop");
		farmer.remove(c);
		c.getCrop().remove(this);
	}
	

	@Override
	public String toString() {
		return "Crop [cropId=" + cropId + ", cropName=" + cropName + ", photo=" + photo + "]";
	}

}
