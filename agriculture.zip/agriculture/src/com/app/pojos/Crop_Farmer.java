package com.app.pojos;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Crop_Farmer {

	private int farmerId;
	private int totalQty;
	private int availableQty;
	private float price;
	
	private User user;
	
	private Set<Crop> crop=new HashSet<>();
	

	public Crop_Farmer() {
	// TODO Auto-generated constructor stub
	}
	public Crop_Farmer(int totalQty, int availableQty, float price) {
		super();
		
		this.totalQty = totalQty;
		this.availableQty = availableQty;
		this.price = price;
		
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getFarmerId() {
		return farmerId;
	}

	public void setFarmerId(int farmerId) {
		this.farmerId = farmerId;
	}

	public int getTotalQty() {
		return totalQty;
	}

	public void setTotalQty(int totalQty) {
		this.totalQty = totalQty;
	}

	public int getAvailableQty() {
		return availableQty;
	}

	public void setAvailableQty(int availableQty) {
		this.availableQty = availableQty;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "user_FK")
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	
	@ManyToMany(cascade = {CascadeType.PERSIST,CascadeType.MERGE})
	@JoinTable(name = "crop_Farm",joinColumns = @JoinColumn(name="farmerid"),inverseJoinColumns = @JoinColumn(name="cropid"))
	@LazyCollection(LazyCollectionOption.FALSE)
	public Set<Crop> getCrop() {
		return crop;
	}

	public void setCrop(Set<Crop> crop) {
		this.crop = crop;
	}
	
	public void addCrop(Crop c)
	{
		crop.add(c);
		c.getFarmer().add(this);
	}
	public void removeCrop(Crop c)
	{
		System.out.println("inside user pojo delete fcrop");
		crop.remove(c);
		c.getFarmer().remove(this);
	}
	

	@Override
	public String toString() {
		return "Farmer [farmerId=" + farmerId + ", totalQty=" + totalQty
				+ ", availableQty=" + availableQty + ", price=" + price + ", crop=" + crop + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + availableQty;
		result = prime * result + ((crop == null) ? 0 : crop.hashCode());
		result = prime * result + farmerId;
		result = prime * result + Float.floatToIntBits(price);
		result = prime * result + totalQty;
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Crop_Farmer other = (Crop_Farmer) obj;
		if (availableQty != other.availableQty)
			return false;
		if (crop == null) {
			if (other.crop != null)
				return false;
		} else if (!crop.equals(other.crop))
			return false;
		if (farmerId != other.farmerId)
			return false;
		if (Float.floatToIntBits(price) != Float.floatToIntBits(other.price))
			return false;
		if (totalQty != other.totalQty)
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}
}
