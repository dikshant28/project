package com.app.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.springframework.web.multipart.MultipartFile;

public class Helper {

	private int wholesellerId;
	private int orderQty;
	private float totalPrice;
	private Integer userId;
	private String password;
	private Role role;
	private String fname;
	private String lname;
	private Date date;
	private String email;
	private String gender;
	private int farmerId;
	private int totalQty;
	private int availableQty;
	private float price;
	private int cropId;
	private String cropName;
	private MultipartFile photo;
	private int courseId;
	private String courseName;
	private int addressId;
	private int houseNo;
	private String area;
	private String city;
	private String district;
	private String state;
	private String country;
	private int pincode;
	private int phoneNo;
	private int enrollId;
	private Date enrollDate;
	private Set<Crop_Farmer> farmer=new HashSet<>();
	private User user;
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Helper() {
		// TODO Auto-generated constructor stub
	}
	
	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getFarmerId() {
		return farmerId;
	}
	public void setFarmerId(int farmerId) {
		this.farmerId = farmerId;
	}
	public int getTotalQty() {
		return totalQty;
	}
	public void setTotalQty(int totalQty) {
		this.totalQty = totalQty;
	}
	public int getAvailableQty() {
		return availableQty;
	}
	public void setAvailableQty(int availableQty) {
		this.availableQty = availableQty;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getCropId() {
		return cropId;
	}
	public void setCropId(int cropId) {
		this.cropId = cropId;
	}
	public String getCropName() {
		return cropName;
	}
	public void setCropName(String cropName) {
		this.cropName = cropName;
	}
	public MultipartFile getPhoto() {
		return photo;
	}
	public void setPhoto(MultipartFile photo) {
		this.photo = photo;
	}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public int getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(int houseNo) {
		this.houseNo = houseNo;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public int getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}
	public int getEnrollId() {
		return enrollId;
	}
	public void setEnrollId(int enrollId) {
		this.enrollId = enrollId;
	}
	public Date getEnrollDate() {
		return enrollDate;
	}
	public void setEnrollDate(Date enrollDate) {
		this.enrollDate = enrollDate;
	}

	public Set<Crop_Farmer> getFarmer() {
		return farmer;
	}

	public void setFarmer(Set<Crop_Farmer> farmer) {
		this.farmer = farmer;
	}

	public int getOrderQty() {
		return orderQty;
	}

	public void setOrderQty(int orderQty) {
		this.orderQty = orderQty;
	}

	public float getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(float totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	public int getWholesellerId() {
		return wholesellerId;
	}

	public void setWholesellerId(int wholesellerId) {
		this.wholesellerId = wholesellerId;
	}
	
	@Override
	public String toString() {
		return "Helper [wholesellerId=" + wholesellerId + ", orderQty=" + orderQty + ", totalPrice=" + totalPrice
				+ ", userId=" + userId + ", password=" + password + ", role=" + role + ", fname=" + fname + ", lname="
				+ lname + ", date=" + date + ", email=" + email + ", gender=" + gender + ", farmerId=" + farmerId
				+ ", totalQty=" + totalQty + ", availableQty=" + availableQty + ", price=" + price + ", cropId="
				+ cropId + ", cropName=" + cropName + ", photo=" + photo + ", courseId=" + courseId + ", courseName="
				+ courseName + ", addressId=" + addressId + ", houseNo=" + houseNo + ", area=" + area + ", city=" + city
				+ ", district=" + district + ", state=" + state + ", country=" + country + ", pincode=" + pincode
				+ ", phoneNo=" + phoneNo + ", enrollId=" + enrollId + ", enrollDate=" + enrollDate + ", farmer="
				+ farmer + ", user=" + user + "]";
	}
}
