package com.app.pojos;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Payment {
	
	private int paymentId;
	private Date payDate;
	private String payMode;
	private int orderRef;
	
	private User user;

	public Payment() {
		super();
	}

	public Payment(int paymentId, int userId, Date payDate, String payMode, int orderRef, User user) {
		super();
		this.paymentId = paymentId;
		this.payDate = payDate;
		this.payMode = payMode;
		this.orderRef = orderRef;
		this.user = user;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}

	public Date getPayDate() {
		return payDate;
	}

	public void setPayDate(Date payDate) {
		this.payDate = payDate;
	}

	public String getPayMode() {
		return payMode;
	}

	public void setPayMode(String payMode) {
		this.payMode = payMode;
	}

	public int getOrderRef() {
		return orderRef;
	}

	public void setOrderRef(int orderRef) {
		this.orderRef = orderRef;
	}

	@ManyToOne
	@JoinColumn(name = "user_FK")
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Payment [paymentId=" + paymentId + ", payDate=" + payDate + ", payMode="
				+ payMode + ", orderRef=" + orderRef + ", user=" + user + "]";
	}
}
