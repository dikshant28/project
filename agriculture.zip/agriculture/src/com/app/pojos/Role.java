package com.app.pojos;

public enum Role {

	Admin,Wholeseller,Farmer,ComputerProfessional
}
