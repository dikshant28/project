package com.app.pojos;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class User {

	private int userId;
	private String password;
	private Role role;
	private String fname;
	private String lname;
	@DateTimeFormat(pattern="dd-MM-yyyy")
	private Date date;
	private String email;
	private String gender;

	private List<Payment> payment;
	
	private List<WholesellerOrder> wholesellerOrder;
	
	private List<Crop_Farmer> cropfarmer;

	private List<CourseEnroll> courseenroll;
	
	private Address address;
	
	@OneToOne(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	@JoinColumn(name = "user_FK")
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public User() {
		super();
	}

	

	public User(int userId, String password, Role role, String fname, String lname, Date date, String email,
			String gender, List<Payment> payment, List<WholesellerOrder> wholesellerOrder, List<Crop_Farmer> cropfarmer,
			Address address) {
		super();
		this.userId = userId;
		this.password = password;
		this.role = role;
		this.fname = fname;
		this.lname = lname;
		this.date = date;
		this.email = email;
		this.gender = gender;
		this.payment = payment;
		this.wholesellerOrder = wholesellerOrder;
		this.cropfarmer = cropfarmer;
		this.address = address;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Enumerated(EnumType.STRING)
	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	
	@JsonIgnore
	@OneToMany(targetEntity = Payment.class, mappedBy = "user", cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	public List<Payment> getPayment() {
		return payment;
	}

	public void setPayment(List<Payment> payment) {
		this.payment = payment;
	}

	@JsonIgnore
	@OneToMany(targetEntity = WholesellerOrder.class,mappedBy = "user",cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	public List<WholesellerOrder> getWholesellerOrder() {
		return wholesellerOrder;
	}

	public void setWholesellerOrder(List<WholesellerOrder> wholesellerOrder) {
		this.wholesellerOrder = wholesellerOrder;
	}
	
	@JsonIgnore
	@OneToMany(targetEntity = Crop_Farmer.class,mappedBy = "user",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	public List<Crop_Farmer> getCropfarmer() {
		return cropfarmer;
	}

	public void setCropfarmer(List<Crop_Farmer> cropfarmer) {
		this.cropfarmer = cropfarmer;
	}
	
	@JsonIgnore
	@OneToMany(targetEntity = Crop_Farmer.class,mappedBy = "user",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	public List<CourseEnroll> getCourseenroll() {
		return courseenroll;
	}

	public void setCourseenroll(List<CourseEnroll> courseenroll) {
		this.courseenroll = courseenroll;
	}
	
	public void addCropfarmer(Crop_Farmer c)
	{
		cropfarmer.add(c);
		c.setUser(this);
	}
	public void removeCropfarmer(Crop_Farmer c)
	{
		System.out.println("inside user pojo delete fcrop");
		cropfarmer.remove(c);
		c.setUser(null);
	}
	
	public void addCourseEnroll(CourseEnroll c)
	{
		courseenroll.add(c);
		c.setUser(this);
	}
	public void removeCourseEnroll(CourseEnroll c)
	{
		System.out.println("inside user pojo delete fcrop");
		courseenroll.remove(c);
		c.setUser(null);
	}
	
	public void addWholesellerOrder(WholesellerOrder c)
	{
		wholesellerOrder.add(c);
		c.setUser(this);
	}
	public void removeWholesellerOrder(WholesellerOrder c)
	{
		System.out.println("inside user pojo delete fcrop");
		wholesellerOrder.remove(c);
		c.setUser(null);
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", password=" + password + ", role=" + role + ", fname=" + fname + ", lname="
				+ lname + ", date=" + date + ", email=" + email + ", gender="+ gender + ", payment=" + payment + ", wholesellerOrder=" + wholesellerOrder + ", cropfarmer="
				+ cropfarmer + ", address=" + address + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((cropfarmer == null) ? 0 : cropfarmer.hashCode());
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((fname == null) ? 0 : fname.hashCode());
		result = prime * result + ((gender == null) ? 0 : gender.hashCode());
		result = prime * result + ((lname == null) ? 0 : lname.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((payment == null) ? 0 : payment.hashCode());
		result = prime * result + ((role == null) ? 0 : role.hashCode());
		result = prime * result + userId;
		result = prime * result + ((wholesellerOrder == null) ? 0 : wholesellerOrder.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (cropfarmer == null) {
			if (other.cropfarmer != null)
				return false;
		} else if (!cropfarmer.equals(other.cropfarmer))
			return false;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (fname == null) {
			if (other.fname != null)
				return false;
		} else if (!fname.equals(other.fname))
			return false;
		if (gender == null) {
			if (other.gender != null)
				return false;
		} else if (!gender.equals(other.gender))
			return false;
		if (lname == null) {
			if (other.lname != null)
				return false;
		} else if (!lname.equals(other.lname))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (payment == null) {
			if (other.payment != null)
				return false;
		} else if (!payment.equals(other.payment))
			return false;
		if (role != other.role)
			return false;
		if (userId != other.userId)
			return false;
		if (wholesellerOrder == null) {
			if (other.wholesellerOrder != null)
				return false;
		} else if (!wholesellerOrder.equals(other.wholesellerOrder))
			return false;
		return true;
	}
	
}
