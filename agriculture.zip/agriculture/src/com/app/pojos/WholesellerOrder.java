package com.app.pojos;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;

@Entity
public class WholesellerOrder {

	private int wholesellerId;
	private int orderQty;
	private Date orderDate;
	private float totalPrice;
	
	private User user;

	public WholesellerOrder() {
		super();
	}

	public WholesellerOrder(int wholesellerId, int orderQty, Date orderDate,float totalPrice, User user) {
		super();
		this.wholesellerId = wholesellerId;
		this.orderQty = orderQty;
		this.orderDate = orderDate;
		this.totalPrice = totalPrice;
		this.user = user;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getWholesellerId() {
		return wholesellerId;
	}

	public void setWholesellerId(int wholesellerId) {
		this.wholesellerId = wholesellerId;
	}

	public int getOrderQty() {
		return orderQty;
	}

	public void setOrderQty(int orderQty) {
		this.orderQty = orderQty;
	}
	
	@PrePersist
	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public float getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(float totalPrice) {
		this.totalPrice = totalPrice;
	}

	@ManyToOne
	@JoinColumn(name = "user_FK")
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "WholesellerOrder [wholesellerId=" + wholesellerId + ", orderQty=" + orderQty + ", orderDate=" + orderDate + ", totalPrice="
				+ totalPrice + "]";
	}
}
